import 'package:flutter/widgets.dart';

class carPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Center(
      child: Container(
        child: Text("Hello Car"),
      ),
    );
  }
}
