import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:pothos/sidebar/sidebar_layout.dart';

class MainScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return SideBarLayout();
  }
}
